package com.example.myapplicationfjhdgjf;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button b, b1;
    int sh1 = 0, sh2 = 0, sh3 = 0,sh4 = 0;
    int a=1, gg = 0, g = 0;
    ImageView img, men6, men5, men4, men3, men2, men1, s1, s2, s3, s4;
    TextView txt, txtt;

    public void tt(int x){
        txt = (TextView) findViewById(R.id.TextView);
        txt.setText( Integer.toString(x));
    }

    public void ttt(String z) {
        txtt = (TextView) findViewById(R.id.textView);
        txtt.setText(z);
    }


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.activity_main);



        b = (Button) findViewById(R.id.b);
        b1 = (Button) findViewById(R.id.b1);
        men1 = (ImageView) findViewById(R.id.imageView3);
        men2 = (ImageView) findViewById(R.id.imageView4);
        men3 = (ImageView) findViewById(R.id.imageView6);
        men4 = (ImageView) findViewById(R.id.imageView8);
        men5 = (ImageView) findViewById(R.id.imageView9);
        men6 = (ImageView) findViewById(R.id.imageView7);
        s1 = (ImageView) findViewById(R.id.imageView11);
        s2 = (ImageView) findViewById(R.id.imageView2);
        s3 = (ImageView) findViewById(R.id.imageView12);
        s4 = (ImageView) findViewById(R.id.imageView13);

        Thread thread = new Thread() {

            @Override
            public void run() {
                try {
                    while (!Thread.currentThread().isInterrupted()) {
                        Thread.sleep(300);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                    if ((Math.random() * 8 + 1) >= 4) {
                                        if ((Math.random() * 8 + 1) >= 3) {
                                            if ((Math.random() * 8 + 1) >= 6) {
                                                if (sh1 == 0)
                                                    sh1 = sh1 + 1;
                                                else
                                                    sh1 = sh1 - 1;
                                                if (sh1 == 0)
                                                    s1.setImageResource(R.drawable.s1_0);
                                                if (sh1 == 1)
                                                    s1.setImageResource(R.drawable.s1_1);
                                                if (sh1 == 2)
                                                    s1.setImageResource(R.drawable.s1_2);
                                                if (sh1 == 3)
                                                    s1.setImageResource(R.drawable.s1_3);
                                            } else {
                                                if (sh1 == 4)
                                                    sh1 = sh1 - 1;
                                                else
                                                    sh1 = sh1 + 1;
                                                if (sh1 == 4) {
                                                    s1.setImageResource(R.drawable.s1_4);
                                                    if (men3.getDrawable().getConstantState() == getResources().getDrawable(R.drawable.men3).getConstantState()){
                                                        ttt("game ower" + " " + Integer.toString(gg));
                                                    men3.setImageResource(R.drawable.nemen3);
                                                    men1.setImageResource(R.drawable.men1);
                                                        tt(0);
                                                        gg = 0;
                                                        g = 0;

                                                }
                                                }
                                                if (sh1 == 1)
                                                    s1.setImageResource(R.drawable.s1_1);
                                                if (sh1 == 2)
                                                    s1.setImageResource(R.drawable.s1_2);
                                                if (sh1 == 3)
                                                    s1.setImageResource(R.drawable.s1_3);
                                            }
                                        } else {
                                            if ((Math.random() * 8 + 1) >= 6) {
                                                if (sh2 == 0)
                                                    sh2 = sh2 + 1;
                                                else
                                                    sh2 = sh2 - 1;
                                                if (sh2 == 0)
                                                    s2.setImageResource(R.drawable.s2_0);
                                                if (sh2 == 1)
                                                    s2.setImageResource(R.drawable.s2_1);
                                                if (sh2 == 2)
                                                    s2.setImageResource(R.drawable.s2_2);
                                                if (sh2 == 3)
                                                    s2.setImageResource(R.drawable.s2_3);
                                                if (sh2 == 3)
                                                    s2.setImageResource(R.drawable.s2_4);
                                            } else {
                                                if (sh2 == 5)
                                                    sh2 = sh2 - 1;
                                                else
                                                    sh2 = sh2 + 1;
                                                if (sh2 == 4)
                                                    s2.setImageResource(R.drawable.s2_4);
                                                if (sh2 == 5) {
                                                    s2.setImageResource(R.drawable.s2_5);
                                                    if (men4.getDrawable().getConstantState() == getResources().getDrawable(R.drawable.men4).getConstantState()){
                                                        ttt("game ower" + " " + Integer.toString(gg));
                                                    men4.setImageResource(R.drawable.nemen4);
                                                    men1.setImageResource(R.drawable.men1);
                                                        tt(0);
                                                        gg = 0;
                                                        g = 0;
                                                }
                                                }
                                                if (sh2 == 1)
                                                    s2.setImageResource(R.drawable.s2_1);
                                                if (sh2 == 2)
                                                    s2.setImageResource(R.drawable.s2_2);
                                                if (sh2 == 3)
                                                    s2.setImageResource(R.drawable.s2_3);
                                            }
                                        }
                                    } else {
                                        if ((Math.random() * 8 + 1) >= 4) {
                                            if ((Math.random() * 8 + 1) >= 6) {
                                                if (sh3 == 0)
                                                    sh3 = sh3 + 1;
                                                else
                                                    sh3 = sh3 - 1;
                                                if (sh3 == 0)
                                                    s3.setImageResource(R.drawable.s3_0);
                                                if (sh3 == 1)
                                                    s3.setImageResource(R.drawable.s3_1);
                                                if (sh3 == 2)
                                                    s3.setImageResource(R.drawable.s3_2);
                                                if (sh3 == 3)
                                                    s3.setImageResource(R.drawable.s3_3);
                                            } else {
                                                if (sh3 == 4)
                                                    sh3 = sh3 - 1;
                                                else
                                                    sh3 = sh3 + 1;
                                                if (sh3 == 4) {
                                                    s3.setImageResource(R.drawable.s3_4);
                                                    if (men5.getDrawable().getConstantState() == getResources().getDrawable(R.drawable.men5).getConstantState()){
                                                        ttt("game ower" + " " + Integer.toString(gg));
                                                    men5.setImageResource(R.drawable.nemen5);
                                                    men1.setImageResource(R.drawable.men1);
                                                        tt(0);
                                                        gg = 0;
                                                        g = 0;
                                                }
                                                }
                                                if (sh3 == 1)
                                                    s3.setImageResource(R.drawable.s3_1);
                                                if (sh3 == 2)
                                                    s3.setImageResource(R.drawable.s3_2);
                                                if (sh3 == 3)
                                                    s3.setImageResource(R.drawable.s3_3);
                                            }
                                        } else {
                                            if ((Math.random() * 8 + 1) >= 6) {
                                                if (sh4 == 0)
                                                    sh4 = sh4 + 1;
                                                else
                                                    sh4 = sh4 - 1;
                                                if (sh4 == 0)
                                                    s4.setImageResource(R.drawable.s4_0);
                                                if (sh4 == 1)
                                                    s4.setImageResource(R.drawable.s4_1);
                                                if (sh4 == 2)
                                                    s4.setImageResource(R.drawable.s4_3);
                                            } else {
                                                if (sh4 == 3)
                                                    sh4 = sh4 - 1;
                                                else
                                                    sh4 = sh4 + 1;
                                                if (sh4 == 3){
                                                    s4.setImageResource(R.drawable.s4_4);
                                                    if (men6.getDrawable().getConstantState() == getResources().getDrawable(R.drawable.men6).getConstantState()){
                                                        ttt("game ower" + " " + Integer.toString(gg));
                                                    men6.setImageResource(R.drawable.nek6);
                                                    men1.setImageResource(R.drawable.men1);
                                                    a = 0;
                                                        tt(0);
                                                        gg = 0;
                                                        g = 0;
                                                    }
                                                }
                                                if (sh4 == 1)
                                                    s4.setImageResource(R.drawable.s4_1);
                                                if (sh4 == 2)
                                                    s4.setImageResource(R.drawable.s4_3);
                                            }
                                        }
                                    }
                                    if((Math.random() * 8 + 1) >= 4){
                                        if ((Math.random() * 8 + 1) >= 4) {
                                            if ((Math.random() * 8 + 1) >= 3) {
                                                if ((Math.random() * 8 + 1) >= 6) {
                                                    if (sh1 == 0)
                                                        sh1 = sh1 + 1;
                                                    else
                                                        sh1 = sh1 - 1;
                                                    if (sh1 == 0)
                                                        s1.setImageResource(R.drawable.s1_0);
                                                    if (sh1 == 1)
                                                        s1.setImageResource(R.drawable.s1_1);
                                                    if (sh1 == 2)
                                                        s1.setImageResource(R.drawable.s1_2);
                                                    if (sh1 == 3)
                                                        s1.setImageResource(R.drawable.s1_3);
                                                } else {
                                                    if (sh1 == 4)
                                                        sh1 = sh1 - 1;
                                                    else
                                                        sh1 = sh1 + 1;
                                                    if (sh1 == 4) {
                                                        s1.setImageResource(R.drawable.s1_4);
                                                        if (men3.getDrawable().getConstantState() == getResources().getDrawable(R.drawable.men3).getConstantState()){
                                                            ttt("game ower" + " " + Integer.toString(gg));
                                                            men3.setImageResource(R.drawable.nemen3);
                                                            men1.setImageResource(R.drawable.men1);
                                                            a = 0;
                                                            tt(0);
                                                            gg = 0;
                                                            g = 0;
                                                        }
                                                    }
                                                    if (sh1 == 1)
                                                        s1.setImageResource(R.drawable.s1_1);
                                                    if (sh1 == 2)
                                                        s1.setImageResource(R.drawable.s1_2);
                                                    if (sh1 == 3)
                                                        s1.setImageResource(R.drawable.s1_3);
                                                }
                                            } else {
                                                if ((Math.random() * 8 + 1) >= 6) {
                                                    if (sh2 == 0)
                                                        sh2 = sh2 + 1;
                                                    else
                                                        sh2 = sh2 - 1;
                                                    if (sh2 == 0)
                                                        s2.setImageResource(R.drawable.s2_0);
                                                    if (sh2 == 1)
                                                        s2.setImageResource(R.drawable.s2_1);
                                                    if (sh2 == 2)
                                                        s2.setImageResource(R.drawable.s2_2);
                                                    if (sh2 == 3)
                                                        s2.setImageResource(R.drawable.s2_3);
                                                    if (sh2 == 3)
                                                        s2.setImageResource(R.drawable.s2_4);
                                                } else {
                                                    if (sh2 == 5)
                                                        sh2 = sh2 - 1;
                                                    else
                                                        sh2 = sh2 + 1;
                                                    if (sh2 == 4)
                                                        s2.setImageResource(R.drawable.s2_4);
                                                    if (sh2 == 5) {
                                                        s2.setImageResource(R.drawable.s2_5);
                                                        if (men4.getDrawable().getConstantState() == getResources().getDrawable(R.drawable.men4).getConstantState()){
                                                            ttt("game ower" + " " + Integer.toString(gg));
                                                            men4.setImageResource(R.drawable.nemen4);
                                                            men1.setImageResource(R.drawable.men1);
                                                            a = 0;
                                                            tt(0);
                                                            gg = 0;
                                                            g = 0;
                                                        }
                                                    }
                                                    if (sh2 == 1)
                                                        s2.setImageResource(R.drawable.s2_1);
                                                    if (sh2 == 2)
                                                        s2.setImageResource(R.drawable.s2_2);
                                                    if (sh2 == 3)
                                                        s2.setImageResource(R.drawable.s2_3);
                                                }
                                            }
                                        } else {
                                            if ((Math.random() * 8 + 1) >= 4) {
                                                if ((Math.random() * 8 + 1) >= 6) {
                                                    if (sh3 == 0)
                                                        sh3 = sh3 + 1;
                                                    else
                                                        sh3 = sh3 - 1;
                                                    if (sh3 == 0)
                                                        s3.setImageResource(R.drawable.s3_0);
                                                    if (sh3 == 1)
                                                        s3.setImageResource(R.drawable.s3_1);
                                                    if (sh3 == 2)
                                                        s3.setImageResource(R.drawable.s3_2);
                                                    if (sh3 == 3)
                                                        s3.setImageResource(R.drawable.s3_3);
                                                } else {
                                                    if (sh3 == 4)
                                                        sh3 = sh3 - 1;
                                                    else
                                                        sh3 = sh3 + 1;
                                                    if (sh3 == 4) {
                                                        s3.setImageResource(R.drawable.s3_4);
                                                        if (men5.getDrawable().getConstantState() == getResources().getDrawable(R.drawable.men5).getConstantState()){
                                                            ttt("game ower" + " " + Integer.toString(gg));
                                                            men5.setImageResource(R.drawable.nemen5);
                                                            men1.setImageResource(R.drawable.men1);
                                                            a = 0;
                                                            tt(0);
                                                            gg = 0;
                                                            g = 0;
                                                        }
                                                    }
                                                    if (sh3 == 1)
                                                        s3.setImageResource(R.drawable.s3_1);
                                                    if (sh3 == 2)
                                                        s3.setImageResource(R.drawable.s3_2);
                                                    if (sh3 == 3)
                                                        s3.setImageResource(R.drawable.s3_3);
                                                }
                                            } else {
                                                if ((Math.random() * 8 + 1) >= 6) {
                                                    if (sh4 == 0)
                                                        sh4 = sh4 + 1;
                                                    else
                                                        sh4 = sh4 - 1;
                                                    if (sh4 == 0)
                                                        s4.setImageResource(R.drawable.s4_0);
                                                    if (sh4 == 1)
                                                        s4.setImageResource(R.drawable.s4_1);
                                                    if (sh4 == 2)
                                                        s4.setImageResource(R.drawable.s4_3);
                                                } else {
                                                    if (sh4 == 3)
                                                        sh4 = sh4 - 1;
                                                    else
                                                        sh4 = sh4 + 1;
                                                    if (sh4 == 3){
                                                        s4.setImageResource(R.drawable.s4_4);
                                                        if (men6.getDrawable().getConstantState() == getResources().getDrawable(R.drawable.men6).getConstantState()){
                                                            ttt("game ower" + " " + Integer.toString(gg));
                                                            men6.setImageResource(R.drawable.nek6);
                                                            men1.setImageResource(R.drawable.men1);
                                                            a = 0;
                                                            tt(0);
                                                            gg = 0;
                                                            g = 0;
                                                        }
                                                    }
                                                    if (sh4 == 1)
                                                        s4.setImageResource(R.drawable.s4_1);
                                                    if (sh4 == 2)
                                                        s4.setImageResource(R.drawable.s4_3);
                                                }
                                            }
                                        }
                                    }
                            }
                        });
                    }
                } catch (InterruptedException e) {
                }
            }
        };


        thread.start();

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ttt("");
                if(a > 0){
                    if (a > 6)
                        a = 6;
                    a = a - 1;
                    if (a == 1) {
                        men1.setImageResource(R.drawable.men1);
                        men2.setImageResource(R.drawable.nemen2);
                    }
                    if (a == 2) {
                        men2.setImageResource(R.drawable.men2);
                        men3.setImageResource(R.drawable.nemen3);
                    }
                    if (a == 3) {
                        men3.setImageResource(R.drawable.men3);
                        men4.setImageResource(R.drawable.nemen4);
                        if (s1.getDrawable().getConstantState() == getResources().getDrawable(R.drawable.s1_4).getConstantState()){
                            ttt("game ower" + " " + Integer.toString(gg));
                            men3.setImageResource(R.drawable.nemen3);
                            men1.setImageResource(R.drawable.men1);
                            a = 0;
                            tt(0);
                            gg = 0;
                            g = 0;
                        }
                    }
                    if (a == 4) {
                        men4.setImageResource(R.drawable.men4);
                        men5.setImageResource(R.drawable.nemen5);
                        if (s2.getDrawable().getConstantState() == getResources().getDrawable(R.drawable.s2_5).getConstantState()){
                            ttt("game ower" + " " + Integer.toString(gg));
                            men4.setImageResource(R.drawable.nemen4);
                            men1.setImageResource(R.drawable.men1);
                            a = 0;
                            tt(0);
                            gg = 0;
                            g = 0;
                        }
                    }
                    if (a == 5) {
                        men5.setImageResource(R.drawable.men5);
                        men6.setImageResource(R.drawable.nek6);
                        if (s3.getDrawable().getConstantState() == getResources().getDrawable(R.drawable.s3_4).getConstantState()){
                            ttt("game ower" + " " + Integer.toString(gg));
                            men5.setImageResource(R.drawable.nemen5);
                            men1.setImageResource(R.drawable.men1);
                            a = 0;
                            tt(0);
                            gg = 0;
                            g = 0;
                        }
                    }
                    if (a == 1){
                        gg = gg + g;
                        g = 0;
                        tt(gg);
                    }
                }

            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ttt("");
                    a = a + 1;
                    if (a == 2) {
                        men2.setImageResource(R.drawable.men2);
                        men1.setImageResource(R.drawable.nemen1);
                    }
                    if (a == 3) {
                        men3.setImageResource(R.drawable.men3);
                        men2.setImageResource(R.drawable.nemen2);
                        if (s1.getDrawable().getConstantState() == getResources().getDrawable(R.drawable.s1_4).getConstantState()){
                            ttt("game ower" + " " + Integer.toString(gg));
                            men3.setImageResource(R.drawable.nemen3);
                            men1.setImageResource(R.drawable.men1);
                            a = 0;
                            tt(0);
                            gg = 0;
                            g = 0;
                        }
                    }
                    if (a == 4) {
                        men4.setImageResource(R.drawable.men4);
                        men3.setImageResource(R.drawable.nemen3);
                        if (s2.getDrawable().getConstantState() == getResources().getDrawable(R.drawable.s2_5).getConstantState()){
                            ttt("game ower" + " " + Integer.toString(gg));
                            men4.setImageResource(R.drawable.nemen4);
                            men1.setImageResource(R.drawable.men1);
                            a = 0;
                            tt(0);
                            gg = 0;
                            g = 0;
                        }
                    }
                    if (a == 5) {
                        men5.setImageResource(R.drawable.men5);
                        men4.setImageResource(R.drawable.nemen4);
                        if (s3.getDrawable().getConstantState() == getResources().getDrawable(R.drawable.s3_4).getConstantState()){
                            ttt("game ower" + " " + Integer.toString(gg));
                            men5.setImageResource(R.drawable.nemen5);
                            men1.setImageResource(R.drawable.men1);
                            a = 0;
                            tt(0);
                            gg = 0;
                            g = 0;
                        }
                    }
                    if (a == 6){
                        men6.setImageResource(R.drawable.men6);
                        men5.setImageResource(R.drawable.nemen5);
                        if (s4.getDrawable().getConstantState() == getResources().getDrawable(R.drawable.s4_4).getConstantState()){
                            ttt("game ower" + " " + Integer.toString(gg));
                            men6.setImageResource(R.drawable.nek6);
                            men1.setImageResource(R.drawable.men1);
                            a = 0;
                            tt(0);
                            gg = 0;
                            g = 0;
                        }
                    }
                    if (a > 6){
                        g = g + 1;
                    }
            }
        });

    }

}